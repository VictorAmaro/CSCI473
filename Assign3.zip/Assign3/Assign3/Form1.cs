﻿/***********************************************************
CSCI 473 - Assignment 3 - Spring 2018

Progammer: Victor Amaro
Z-ID: z1747708
Section: 2
Date Due: March 7, 2018

Purpose: Use a form to handle some user sql statements
************************************************************/
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using System.Text.RegularExpressions;

namespace Assign3 {
    public partial class Form1 : Form
    {
        public const String SQL_CONNECTION = "server=*****;uid=csci473g16;pwd=wordpass16;database=csci473g16;";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            aestheticChanges();
            dropTables();
            loadInOffice();
            loadInRoom();
            loadInClass();
            getTables();
        }

        /**************************************************
         * aestheticChanges()
         * use: 1) changes background color
         *  2) changes forground color
         *  3) changes sqlLabel font and font size
         *  4) changes resultLabel font and font size
         *  5) changes executeButton font and font size
         *  6) changes clearButton font and font size
         *  7) changes exitButton font and font size
         * ***********************************************/
        private void aestheticChanges() {
            BackColor = Color.MidnightBlue;
            ForeColor = Color.WhiteSmoke;

            sqlLabel.Font = new Font("Consolas", 10);
            resultLabel.Font = new Font("Consolas", 10);

            executeButton.Font = new Font("Consolas", 10);
            clearButton.Font = new Font("Consolas", 10);
            exitButton.Font = new Font("Consolas", 10);
        }

        /**************************************************
         * dropTables()
         * use: 1) drops ClassTable if exists
         *  2) drops OfficeTable if exists
         *  3) drops RoomTable if exists
         * ***********************************************/
        private void dropTables() {
            using (MySqlConnection connection = new MySqlConnection(SQL_CONNECTION)) {
                connection.Open();

                string sqlQuery = "DROP TABLE IF EXISTS ClassTable;";                    //Drop table if already present
                MySqlCommand sqlCommand = new MySqlCommand(sqlQuery, connection);
                MySqlDataReader sqlReader = sqlCommand.ExecuteReader();
                sqlReader.Close();

                sqlQuery = "DROP TABLE IF EXISTS OfficeTable;";                          //Drop table if already present
                MySqlCommand sqlCommand2 = new MySqlCommand(sqlQuery, connection);
                MySqlDataReader sqlReader2 = sqlCommand2.ExecuteReader();
                sqlReader2.Close();

                sqlQuery = "DROP TABLE IF EXISTS RoomTable;";                            //Drop table if already present
                MySqlCommand sqlCommand3 = new MySqlCommand(sqlQuery, connection);
                MySqlDataReader sqlReader3 = sqlCommand3.ExecuteReader();
                sqlReader3.Close();
            }
        }

        /**************************************************
         * loadInClass()
         * use: 1) opens a MySql connection
         *  2) drops table (RoomTable) if already exists
         *  3) create the new table called ClassTable
         *  4) Opens txt file and store the contents in Strings,
         *      to be inserted into the table, then inserts them
         *  5) closes file
         * ***********************************************/
        private void loadInClass() {
            using(MySqlConnection connection = new MySqlConnection(SQL_CONNECTION)) {
                connection.Open();

               string sqlQuery = "CREATE Table ClassTable" +                             //Create query to create table called ClassTable
                   "(Class VARCHAR(20), Teacher VARCHAR(20), Room Int, " +
                   "Time VARCHAR(5), Days VARCHAR(5), Enrollment INT, "  +
                   "PRIMARY KEY(Class), FOREIGN KEY (Teacher) REFERENCES OfficeTable(Teacher), FOREIGN KEY (Room) REFERENCES RoomTable(Room));";
                MySqlCommand sqlCommand2 = new MySqlCommand(sqlQuery, connection);
                MySqlDataReader sqlReader2 = sqlCommand2.ExecuteReader();
                sqlReader2.Close();

                String currentLine,                                                     //Vars to hold contents from .txt file and regex pattern to parse
                    pattern = @"\,";

                StreamReader inFile = new StreamReader("Class.txt");                    //Opens .txt file
                currentLine = inFile.ReadLine();
                while (currentLine != null) {                                           //While there is contents to grab from file
                    String[] splits = Regex.Split(currentLine, pattern);                //Spilts the string from file into a string array, parsed by a comma

                    stringTrim(splits);                                                 //Trim string

                    sqlQuery = "INSERT INTO ClassTable(Class, Teacher, Room, Time, Days, Enrollment) VALUES" +
                        "(\'" + splits[0] + "\', \'" + splits[1] + "\' ," + splits[2] + ", \'" + splits[3] + "\', \'" + splits[4] + "\', " + splits[5] + ");";
                    MySqlCommand sqlCommand3 = new MySqlCommand(sqlQuery, connection);
                    var result = sqlCommand3.ExecuteNonQuery();
                    
                    currentLine = inFile.ReadLine();                                    //Get next line from txt file
                }
                inFile.Close();
            } 
        }

        /**************************************************
         * loadInOffice()
         * use: 1) opens a MySql connection
         *  2) drops table (RoomTable) if already exists
         *  3) create the new table called OfficeTable
         *  4) Opens txt file and store the contents in Strings,
         *      to be Instered into the table, then inserts them
         *  5) closes file
         * ***********************************************/
        private void loadInOffice() {
            using(MySqlConnection connection = new MySqlConnection(SQL_CONNECTION)) {
                connection.Open();

                string sqlQuery = "CREATE TABLE OfficeTable " +                         //Create query to create table called OfficeTable
                    "(Teacher VARCHAR(20) PRIMARY KEY, Office INT);";
                MySqlCommand sqlCommand2 = new MySqlCommand(sqlQuery, connection);
                MySqlDataReader sqlReader2 = sqlCommand2.ExecuteReader();
                sqlReader2.Close();

                String currentLine,                                                     //Vars to hold contents from .txt file and regex pattern to parse
                    pattern = @"\,";

                StreamReader inFile = new StreamReader("Office.txt");                   //Opens .txt file
                currentLine = inFile.ReadLine();
                while (currentLine != null) {                                           //While there is contents to grab from file
                    String[] splits = Regex.Split(currentLine, pattern);                //Spilts the string from file into a string array, parsed by a comma

                    stringTrim(splits);                                                 //Trim string

                    sqlQuery = "INSERT INTO OfficeTable (Teacher, Office) VALUES " +   //Create query to insert values into table
                        "(\'" + splits[0] + "\'," + splits[1] + ");";

                    MySqlCommand sqlCommand3 = new MySqlCommand(sqlQuery, connection);
                    var result = sqlCommand3.ExecuteNonQuery(); 

                    currentLine = inFile.ReadLine();                                    //Get next line from txt file
                }
                inFile.Close();
            }
        }

        /**************************************************
         * loadInRoom()
         * use: 1) opens a MySql connection
         *  2) drops table (RoomTable) if already exists
         *  3) create the new table called RoomTable
         *  4) Opens txt file and store the contents in Strings,
         *      to be Instered into the table, then inserts them
         *  5) closes file
         * ***********************************************/
        private void loadInRoom() {
            using (MySqlConnection connection = new MySqlConnection(SQL_CONNECTION)) {  //Open connection
                connection.Open();           

                string sqlQuery = "CREATE TABLE RoomTable " +                           //Create query to create table called RoomTable
                    "(Room INT PRIMARY KEY, " +
                    "Capacity INT, " +
                    "Smart VARCHAR(1));";
                MySqlCommand sqlCommand2 = new MySqlCommand(sqlQuery, connection);
                MySqlDataReader sqlReader2 = sqlCommand2.ExecuteReader();
                sqlReader2.Close();

                String currentLine,                                                     //Vars to hold contents from .txt file and regex pattern to parse
                    pattern = @"\,";

                StreamReader inFile = new StreamReader("Room.txt");                     //Opens .txt file
                currentLine = inFile.ReadLine();
                while (currentLine != null) {                                           //While there is contents to grab from file
                    String[] splits = Regex.Split(currentLine, pattern);                //Spilts the string from file into a string array, parsed by a comma

                    stringTrim(splits);                                                 //Trim string

                    sqlQuery = "INSERT INTO RoomTable (Room, Capacity, Smart) VALUES " +    //Create query to insert values into table
                        "(" + (splits[0]) + ", " + splits[1] + ",\'" + splits[2] + "\');";
                    MySqlCommand sqlCommand3 = new MySqlCommand(sqlQuery, connection);
                    var result = sqlCommand3.ExecuteNonQuery();

                    currentLine = inFile.ReadLine();                                    //Get next line from txt file
                }
                inFile.Close();
            } 
        }

        /**********************************************
         * getTables()
         * Use: Returns the name of tables in database
         * ********************************************/
        private void getTables() {
            using (MySqlConnection connection = new MySqlConnection(SQL_CONNECTION)) {  //Open connection
                connection.Open();

                DataTable tableInfo = connection.GetSchema("Tables");

                resultBox.Items.Add("Name Of Tables:");

                foreach (DataRow row in tableInfo.Rows)
                    resultBox.Items.Add(row[2].ToString());
            }
        }

        /**************************************************
         * clearButton_Click(object sender, EventArgs e)
         * Use: 1) Clears list box and text box when clear button is clicked
         * ***********************************************/
        private void clearButton_Click(object sender, EventArgs e) {
            resultBox.Items.Clear();
            sqlTextBox.Clear();
        }

        /**************************************************
         * exitButton_Click(object sender, EventArgs e)
         * Use: 1) Closes form when the Exit button is clicked
         * ***********************************************/
        private void exitButton_Click(object sender, EventArgs e) {
            Application.Exit();
        }

        /**************************************************
         * executeButton_Click(object sender, EventArgs e)
         * Use: 1) sets regex patterns
         *          one to spilt the user string (by every space)
         *          one to find out when user entered COUNT( followed by anything
         *      2) splits uder string
         *          trims strings
         *      3) checks if user entered SELECT
         *          if just SELECT, will call selectWork
         *          if SELECT COUNT, will call selectCountWork
         *      4) checks if user entered INSERT
         *          will call insertWork
         *      5) user entered something not supported, display message
         * ***********************************************/
        private void executeButton_Click(object sender, EventArgs e) {
            String pattern = @"\s",                                         //Sets regex pattern, to a space
                pattern2 = @"COUNT(\(*)",
                eventString = sqlTextBox.Text.ToString();                   //sets the sqlTextBox contents to a string var

            String[] splits = Regex.Split(eventString, pattern);            //Spilts the string from file into a string array, parsed by a space

            stringTrim(splits);

            if (splits[0].ToUpper().Equals("SELECT")) {                     //user entered select
                try {
                    if(Regex.IsMatch(splits[1].ToUpper(), pattern2 )) {     //was it select count?
                        selectCountWork(eventString);
                    }
                    else {                                                  //user only entered select
                        selectWork(eventString);
                    }
                }
                catch (IndexOutOfRangeException ex) {                       //only select was entered with nothing afterwords
                    selectWork(eventString);
                }
            }
            else if (splits[0].ToUpper().Equals("INSERT"))  {               //user entered insert
                insertWork(eventString);
            }
            else {                                                          //user entered something not supported
                resultBox.Items.Add("");
                resultBox.Items.Add("Sorry, that SQL command isnt supported yet!");
            }
        }

        /**************************************************
         * stringTrim(string[])
         * Use: 1) trims the string in the array
         * ***********************************************/
        private void stringTrim(string[] stringT) {
            foreach (var trimString in stringT)
                trimString.Trim();
        }

        /**************************************************
         * selectWork(string)
         * arguments: 1) a string that contain the sql command
         * use :1) opens mysql connection
         *  2) attempts to execute the select statement
         *      if it passes, 
         *          then loop through the sqlReader getting its items,
         *          then adding them to a string,
         *          then printing that string containing items into the list box (resultBox)
         *      displays a message saying it failed if it doesnt execute
         * ***********************************************/
        private void selectWork(string sqlString) {
            using (MySqlConnection connection = new MySqlConnection(SQL_CONNECTION)) {  //Open connection
                connection.Open();

                MySqlCommand sqlCommand = new MySqlCommand(sqlString, connection);      //create query from the string
                resultBox.Items.Add("");                                                //new line

                try {
                    MySqlDataReader sqlReader = sqlCommand.ExecuteReader();             //execute the query 

                    while (sqlReader.Read())  {                                         //while reader has data
                        string outString = string.Empty;
                        for (int k = 0; k < sqlReader.FieldCount; k++) {                //go throught the field count
                            outString += String.Format("{0, -8}", sqlReader[k]);        //add item to string
                        }
                        resultBox.Items.Add(outString);                                //add the string to the list box (resultBox)
                    }
                } catch (MySqlException ex){
                    resultBox.Items.Add("Could not execute the Select statement!");    //print a message sayig select query failed
                }
            }
        }

        /**************************************************
         * selectCountWork(string )
         * arguments: 1) a string that contain the sql command
         * use: 1) opens mysql connection
         *  2) attempts to execute the select count statement
         *      displays a message saying is passed if it does execute 
         *      displays a message saying it failed if it doesnt execute
         * ***********************************************/
        private void selectCountWork(string sqlString) {
            using (MySqlConnection connection = new MySqlConnection(SQL_CONNECTION)) { 
                connection.Open();                                                          //Open connection

                MySqlCommand sqlCommand = new MySqlCommand(sqlString, connection);          //create query from the string
                resultBox.Items.Add("");                                                    //new line

                try {
                    var res = sqlCommand.ExecuteScalar();                                   //execute the query
                    resultBox.Items.Add("Count -> " + res);                                 //print a message for the count if query passed
                } catch (MySqlException ex) {
                    resultBox.Items.Add("Could not execute the Select Count statement!");  //print a message saying query failed
                }
            }
        }

        /**************************************************
         * insertWOrk(string )
         * arguments: 1) a string that contain the sql command
         * use: 1) opens mysql connection
         *  2) attempts to execute the insert statement
         *      displays a message saying is passed if it does execute 
         *      displays a message saying it failed if it doesnt execute
         * ***********************************************/
        private void insertWork(string sqlString) {
            using (MySqlConnection connection = new MySqlConnection(SQL_CONNECTION)) {
                connection.Open();                                                      //Open MySql connection

                MySqlCommand sqlCommand3 = new MySqlCommand(sqlString, connection);     //create the query from the string

                resultBox.Items.Add("");                                                //Print a new line

                try {
                    var result = sqlCommand3.ExecuteNonQuery();                         //execute the query
                    resultBox.Items.Add("Added " + result + " row to table!");          //print a message if query passed
                } catch (MySqlException ex) {
                    resultBox.Items.Add("Could not execute the Insert statement!");    //print a message if query didnt pass
                }
            }
        }
    }
}
